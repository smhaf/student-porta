<div class="w3-row w3-center w3-margin-top w3-margin-bottom">
  <div class="w3-container w3-quarter">
    <div class='w3-container w3-white w3-card' style="height:150px">
      <h2><i class="fa fa-book w3-jumbo w3-text-orange" aria-hidden="true"></i></h2>
      <p>Bacalah Buku</p>
    </div>
  </div>
  <div class="w3-container w3-quarter">
    <div class='w3-container w3-white w3-card' style="height:150px">
      <h2><i class="fa fa-clock-o w3-jumbo w3-text-black" aria-hidden="true"></i></h2>
      <p>Masa Itu Emas</p>
    </div>
  </div>
  <div class="w3-container w3-quarter">
    <div class='w3-container w3-white w3-card' style="height:150px">
      <h2><i class="fa fa-calendar w3-jumbo w3-text-red" aria-hidden="true"></i></h2>
      <p>Ingat Pada Tarikh Peperiksaan</p>
    </div>
  </div>
  <div class="w3-container w3-quarter">
    <div class='w3-container w3-white w3-card' style="height:150px">
      <h2><i class="fa fa-birthday-cake w3-jumbo w3-text-pink" aria-hidden="true"></i></h2>
      <p>Kek</p>
    </div>
  </div>
</div>