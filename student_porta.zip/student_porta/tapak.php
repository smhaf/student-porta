class='w3-block w3-button w3-white w3-border w3-border-purple w3-round-large'

<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>

title='Kemaskini'><i class='w3-xxlarge fa fa-pencil-square-o' aria-hidden='true'></i></a>

title='Padam'><i class='w3-xxlarge fa fa-trash' aria-hidden='true'></i></a>

<div class='w3-center w3-panel w3-topbar w3-bottombar w3-border-purple w3-pale-red'>
<h3>Senarai Guru</h3></div>
<?PHP include ('../butang_saiz.php'); ?>
<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>

class='w3-input'

w3-input w3-border  w3-round-large w3-hover-gre