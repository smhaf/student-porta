<?php
# memulakan fungsin session
session_start();

# menhapuskan nilai pembolehubah session
session_unset();

# menghentikan fungsi session
session_destroy();

# membuka fail index.php
echo"<script>window.location.href='index.php';</script>";
?>