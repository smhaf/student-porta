<div class='w3-container w3-center w3-margin-top w3-margin-bottom'>
  <img src='images/iklang.png' class='w3-image'>
</div>