<?php
#semak kewujudan data pada pemboleh ubah sesion [nama_murid]
if(empty($_SESSION['nama_murid']))
{
	# jika pembolehubah session tidak mempunyai nilai, papar pop up dan
	# buka fail index dilaman utama
	die("<script>alert('akses tanpa kebenaran. Sila Login');
		window.location.href='../index.php';</script>");
}
?>