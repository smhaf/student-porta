<?PHP

include('../header.php');
include('guard_murid.php');
include('../connection.php');

# fungsi untuk mengira skor berdasarkan noset soalan
function skor($no_set,$bil_soalan)
{
	include ('../connection.php');

	# arahan untuk mendapatkan data jawapan murid
	$arahan_skor="SELECT *
	FROM set_soalan,soalan,jawapan_murid
	where 
	    set_soalan.no_set           =   soalan.no_set
	and soalan.no_soalan            =   jawapan_murid.no_soalan
	and set_soalan.no_set           =   '$no_set'
	and jawapan_murid.nokp_murid    =   '".$_SESSION['nokp_murid']."' ";

	# melaksanakan arahan untuk mendapatkan data jawapan
	$laksana_skor=mysqli_query($condb,$arahan_skor);

	# mengira bilangan jawapan
	$bil_jawapan=mysqli_num_rows($laksana_skor);
	$bil_betul=0;

	#pemboleh ubah rekod mengambil data yang ditemui semasa laksanakan arahan
	while($rekod=mysqli_fetch_array($laksana_skor))
	{
		# mengira jawapan yang betul
		switch($rekod['catatan'])
		{
			case 'BETUL': $bil_betul++; break;
			default: break;
			
		}
	}

	#mengira peratus yang betul
	$peratus=$bil_betul/$bil_soalan*100;

	#memaparlan slor dan markah dalam %
	echo"  <td class='w3-center' align='right'>$bil_betul/$bil_soalan</td>
	       <td class='w3-center' align='right'>".number_format($peratus,0)."%</td>";
	       $kumpul=$bil_betul."|".$bil_soalan."|".$peratus."|".$bil_jawapan;
	# memulangkan nilai bil betul ,bil soalan, peratus dan bilangan jawapan
	return $kumpul;
}
?>

<!-- memanggil fail butang dari folder luaran untk membesarkan saiz tulisan-->
<?PHP include ('../butang_saiz.php'); ?>

<!-- bahagian memaparkan maklumat set soalan-->
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>
	<tr class='w3-purple'>
		<td class='w3-center'>Bil</td>
		<td class='w3-center'>topik</td>
		<td class='w3-center'>Jenis latihan</td>
		<td class='w3-center'>Bil soalan</td>
		<td class='w3-center'>Skor</td>
		<td class='w3-center'>Peratus</td>
		<td class='w3-center'>Jawap</td>
	</tr>

<?PHP
# arahan untuk mendapatkan maklumat murid berdasarkan data session
$arahan_cari="select*from murid
where
nokp_murid='".$_SESSION['nokp_murid']."' ";

# laksana arahan di atas
$laksana_cari=mysqli_query($condb,$arahan_cari);

#mengambil data yang ditemui 
$data_murid=mysqli_fetch_array($laksana_cari);

#arahan untuk mencari data set soalan
$arahan_pilih_latihan="SELECT
set_soalan.no_set,
COUNT(soalan.no_soalan) AS bil_soalan,
topik, jenis
FROM set_soalan,soalan,guru,kelas
where
            set_soalan.no_set        =      soalan.no_set
and         set_soalan.nokp_guru     =      guru.nokp_guru
and         kelas.nokp_guru          =      guru.nokp_guru
and         kelas.id_kelas           =      '".$data_murid['id_kelas']."'
group by    topik";

#melaksanakan arahan untuk mencaru data set soalan
$laksana=mysqli_query($condb,$arahan_pilih_latihan);
$i=0;

# pemboleh ubah data mengabil settiap data set soalan
while ($data=mysqli_fetch_array($laksana))
{
	# memapar data set soalan yang ditemui
	echo "<tr>
	<td class='w3-center'>".++$i."</td>
	<td>".$data['topik']."</td>
	<td>".$data['jenis']."</td>
	<td class='w3-center' align='center'>".$data['bil_soalan']."</td> ";

	#memanggil fungsi skor dengan menghantar no set soalan dan balnagan soalan
	$kumpul=skor($data['no_set'],$data['bil_soalan']);

	#menerima dan memecahkan data yang diterima kembali dari fungsi skor
	$pecahkanbaris = explode("|",$kumpul);

	#umpukkan kepada pembolehubah dibawah
	list($bil_betul,$bil_soalan,$peratus,$bil_jawapan) = $pecahkanbaris;

	# menguji bilangan jawapan yang ditemui
	if ($bil_jawapan<=0)
	{
		# jika biljawapan<=0 bermalsud murid belum menjawab soalan
		echo "<td><a class='w3-block w3-button w3-white w3-border w3-border-purple w3-round-large' href='arahan_latihan.php?no_set=".$data['no_set']."'>Pilih</a></td>";
	}
	else
	{
		#jika tidak,murid hanya boleh mengulangkaju seula soalan yang telah dijawap
		echo "<td><a class='w3-block w3-button w3-white w3-border w3-border-purple w3-round-large' href='ulangkaji.php?no_set=".$data['no_set']."&topik=".$data['topik']."&kumpul=".$kumpul."'>Ulangkaji</a></td>";
	}
echo "</tr>";
}
?>
</table>
<?PHP include ('../footer.php') ?>