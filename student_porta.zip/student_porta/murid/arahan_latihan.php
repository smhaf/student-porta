<?PHP
include ('../header.php');
include ('../connection.php');

# menguji kewujudan data get
if(empty($_GET))
{
	# menghenti atur cara jika tiada data get
	die("<script>alert('Akses tanpa kebenaran');
	window.location.href='pilih_latihan.php';</script>");
}

#arahan untuk memilih set soalan berdasarkan no set soalan
$arahan_pilih_set  =   "select* from set_soalan where no_set='".$_GET['no_set']."' ";

# melaksanakan arahan untuk memilih
$laksana           =   mysqli_query($condb,$arahan_pilih_set);

# pemboleh ubah data mengamnbil data yang ditemui
$data              =   mysqli_fetch_array($laksana)
?>

<div class="w3-row w3-margin-top">
  <div class="w3-quarter w3-container">
    
  </div>
  <div class="w3-half w3-container w3-center w3-card">
    
        <!-- memaparkan arahan untuk menjawab soalan-->
        <h3>Arahan</h3>
        <hr>
        <?PHP echo $data['arahan']; ?><br>

        <a class='w3-margin-bottom w3-button w3-blue w3-border w3-border-purple w3-round-large w3-block' href='jawap_soalan.php?no_set=<?PHP echo $_GET['no_set']; ?>&masa=<?PHP echo $data['masa']; ?>&jenis=<?PHP echo $data['jenis']; ?>'>Mula</a>

  </div>
  <div class="w3-quarter w3-container">
    
  </div>
</div>



<?PHP include ('../footer.php'); ?>