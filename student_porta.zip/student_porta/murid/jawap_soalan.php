<?PHP
include ('../header.php');
include ('../connection.php');

#menyemak kewujudan data get
if(empty($_GET))
{
	# menghenti atur cara jika tiada data get
	die("<script>alert('Akses tanpa kebenaran');
	window.location.href='pilih_latihan.php';</script>");
}
?>

<?PHP

#menguji data jenis GET[jenis]==kuiz
if($_GET['jenis']=="Kuiz")
{
	include ('timer2.php');
	# memanggil fungsi timer kuiz
	timer_kuiz($_GET['masa']);
}
?>

<!-- memaparkan latihan untuk dijawab oleh pelajar-->
<h3 class='w3-center'>Soalan Latihan</h3>
<hr>
<form name='soalan_kuiz' action='jawap_semak.php?no_set=<?PHP echo $_GET['no_set']; ?>' method='POST'>
<?php include ('../butang_saiz.php'); ?>

<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>
	<tr class='w3-purple'>
		<td style="width:5%">Bil</td>
		<td>soalan</td>
	</tr>

<?php 
#arahan untuk memilih soalan berdasarkan noset dan mnyusunnya secara rawak 
$arahan_pilih_soalan="select* from soalan where no_set='".$_GET['no_set']."'
order by rand()";

#laksana arahan diatas
$laksana=mysqli_query($condb,$arahan_pilih_soalan);
$i=0;

# pemboleh ubah data mengambil data yang ditemui
while ($data=mysqli_fetch_array($laksana))
{
	# memapar soalan dan jawapan
	echo"<tr>
	<td>".++$i."</td>
	<td>";

	#mengumpukkan nama medan kepada tatasusunan
	$a=array("jawapan_a","jawapan_b");

	# menjadikan susunan kepada rawak
	shuffle($a);
	$xjawap='TIDAK MENJAWAB';

	#memaparkan jawpan yang telah disusun secara rawak
	echo $soalan=str_replace("'"," ",$data['soalan']);

	# susunan value yang dihantar.
	#medan,jawapan,jawapan1,jawaoan2,soalan,nilai jawapan _a,
	echo"
<br><input class='w3-radio' type='radio' name='s".$data['no_soalan']."' value='".$a[0]."|".$data[$a[0]]."|".$data[$a[0]]."|".$data[$a[1]]."|".$soalan."|".$data['jawapan_a']."'> <label>".$data[$a[0]]."</label><br>

<input class='w3-radio' type='radio' name='s".$data['no_soalan']."' value='".$a[1]."|".$data[$a[1]]."|".$data[$a[0]]."|".$data[$a[1]]."|".$soalan."|".$data['jawapan_a']."'> <label>".$data[$a[1]]."</label><br>

<input type='radio' name='s".$data['no_soalan']."' value='tidak jawab|tidak jawab|".$data[$a[0]]."|".$data[$a[1]]."|".$soalan."|".$data['jawapan_a']."' checked style='visibility: hidden'>

<br>";

echo"</td>
</tr>";
}
?>

</table>
</div>
<button class='w3-block w3-margin-top w3-button w3-white w3-border w3-border-purple w3-round-large' value="sumbit">Hantar </button>

</form>
<?php include ('../footer.php'); ?>