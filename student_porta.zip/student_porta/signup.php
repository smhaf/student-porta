<?php
# memanggil fail header.php dan connection.php
include('header.php');
include('connection.php');

# menguji kewujudan data POST yang dihantar oleh bahagian borang di bawah
if (!empty($_POST)) 
{
	# mengambil dan menapis data POST
	$nama         =  mysqli_real_escape_string($condb,$_POST['nama']);
	$nokp         =  mysqli_real_escape_string($condb,$_POST['nokp']);
	$katalaluan   =  mysqli_real_escape_string($condb,$_POST['katalaluan']);
	$id_kelas     =  $_POST['id_kelas'];

	# menyemak kewujudan data yang dimasukkan
	if (empty($nama) or empty($nokp) or empty($katalaluan) or empty($id_kelas)) 
	{
		die("<script>alert('sila lengkapkan maklumat')
	    window.history.back();</script>");
    }

    #had atas dan had bawah : sebagai data validation kepada nokp
    if (strlen($nokp)!=12 or !is_numeric($nokp)) 
    {
    	die("<script>alert('Ralat No K/P.');
    	window.history.back();</script>");
    }

    # arahan untuk menyimpan data murid dimasukkan
    $arahan_simpan="insert into murid
    (nama_murid,nokp_murid,katalaluan_murid,id_kelas)
    values 
    ('$nama','$nokp','$katalaluan','$id_kelas')";

    #laksanakan arahan dalam blok if
    if (mysqli_query($condb,$arahan_simpan)) 
    {
    	# data berjaya disimpan, papar popup
    	echo "<script>alert('Pendaftaran BERJAYA.');
    	window.location.href='index.php';</script>";
    }
    else
    {
    	# data gagal disimpan, papar popup
    	echo "<script>alert('Pendaftaran GAGAL.);
    	window.location.href='index.php';</script>";
    }
}
?>

<div class="w3-row w3-white w3-margin-top w3-round-xlarge">
  <div class="w3-third w3-container w3-green">
    <!-- Bahagian borang untuk mendaftar murid baru -->
<h3>Pendaftaran Murid Baru</h3>
<form action='' method='POST'>
    <label class="w3-text-grey"><b>Nama Murid</b></label>
    <input class="w3-input w3-border  w3-round-large w3-hover-grey" name='nama' type="text">
    <label class="w3-text-grey"><b>No K/P Murid</b></label>
    <input class="w3-input w3-border  w3-round-large w3-hover-grey" name='nokp' placeholder='040503010203' type="text">
    <label class="w3-text-grey"><b>Katalaluan</b></label>
    <input class="w3-input w3-border  w3-round-large w3-hover-grey" type='password' name='katalaluan'>
    <label class="w3-text-grey"><b>Kelas</b></label>
    <select class="w3-select w3-border w3-round-large" name='id_kelas'>

                    <option value selected disable>Pilih</option>

<?php
# arahan untuk mencari data dari jadual kelas
$sql="select* FROM kelas";

# melaksanakan arahan mencari data
$laksana_arahan_cari = mysqli_query($condb,$sql);

#pemboleh ubah $rekod_bilik mengambil data yang ditemui baris demi baris
while ($rekod_bilik = mysqli_fetch_array($laksana_arahan_cari)) 
{
# memaparkan data yang ditemui dalam element <option></option>
echo "<option value=".$rekod_bilik['id_kelas'].">".$rekod_bilik['tingkatan']."
".$rekod_bilik['nama_kelas']."</option>";
}
?>

</select><br>
<input class="w3-margin-top w3-button w3-white w3-border w3-border-purple w3-round-large" type='submit' value='Daftar'>
<a class="w3-margin-top w3-button w3-white w3-border w3-border-purple w3-round-large" href='index.php'>Kembali Ke Laman Log Masuk</a>
</form>
  </div>
  <div class="w3-twothird w3-container">
    <img src='images/su.png' class='image'>
  </div>
</div>



<?php
mysqli_close($condb);
include ('footer.php');
?>