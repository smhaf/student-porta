<?PHP 
#memanggil fail headaer guru
include('header_guru.php');

# bahagian untuk menyimpan data yang telah dikemaskini
# menyemak kewujudan data GET
if(empty($_GET))
{
	die("<script>alert('Akses tanpa kebenaran. '); window.location.href='soalan_daftar.php/no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script> ");
}

#menyemak kewujudan data post
if(!empty($_POST))
{
	# mengambil data post
	$soalan     =   mysqli_real_escape_string($condb,$_POST['soalan']);
	$jawapan_a  =   mysqli_real_escape_string($condb,$_POST['jawapan_a']);
	$jawapan_b  =   mysqli_real_escape_string($condb,$_POST['jawapan_b']);

	# menyemak kewujudan data post
	if(empty($soalan) or empty($jawapan_a) or empty($jawapan_b))
	{
		die("<script>alert('Sila lengkapkan makluamat');
		window.history.back();</script>");
	}
	# arahan untuk mengemaskini soalan dan jawapan
	$arahan_kemaskini="update soalan
	set
	soalan      =   '".$_POST['soalan']."',
	jawapan_a   =   '".$_POST['jawapan_a']."',
	jawapan_b   =   '".$_POST['jawapan_b']."'
	where
	no_soalan   =   '".$_GET['no_soalan']."' ";

	# melaksanakan arahan untuk mengemas kini soalan
	if (mysqli_query($condb,$arahan_kemaskini))
	{
		# soalan berjaya dikemaskini
		echo "<script>alert('Kemaskini BERJAYA');window.location.href ='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
	}
	else
	{
		# soalan gagal dikemaskini
		echo "<script>alert('Kemaskini GAGAL');window.location.href ='soalan_daftar.php?no_set=".$_GET['no_set']."&topik=".$_GET['topik']."';</script>";
	}	
}
?>

<!-- bahagian untuk memaparkan soalan yang telah didafterkan-->
<div class='w3-center w3-panel w3-topbar w3-bottombar w3-border-purple w3-pale-red'>
<h3>Senarai Guru</h3></div>
<?PHP include ('../butang_saiz.php'); ?>
<div class='w3-responsive'>
<table border='1' id='besar' class='w3-table-all w3-hoverable w3-margin-top'>
	<tr class='w3-purple'>
		<td>Soalan</td>
		<td bgcolor='cyan'>Jawpanan A (Betul)</td>
		<td bgcolor='pink'>Jawpanan B</td>
		<td></td>
	</tr>
	<tr>

    <!-- bahagian borang untuk mengemaskini soalan dan jawapan-->
    <form action='' method='POST'>
    	<td><textarea class='w3-input' name='soalan' rows="4" cols="25"><?PHP echo $_GET['soalan']; ?></textarea></td>
    	<td><textarea class='w3-input' name='jawapan_a' rows="4" cols="25"><?PHP echo $_GET['jawapan_a']; ?></textarea></td>
    	<td><textarea class='w3-input' name='jawapan_b' rows="4" cols="25"><?PHP echo $_GET['jawapan_b']; ?></textarea></td>
    	<td><button class='w3-block w3-button w3-white w3-border w3-border-purple w3-round-large' value="sumbit">simpan</button></td>

    </form>
    </tr>
<?PHP

#arahan untuk mencari soalan yang berkaitan dengan set soalan yang dipilih
$arahan_soalan="select* from soalan
where no_set   =   '".$_GET['no_set']."'
order by no_soalan DESC";

# melaksanakan arahan untuk mencari soalan
$laksana_soalan=mysqli_query($condb,$arahan_soalan);

# pembolehubah 4data mengambil data yang ditemui
while ($data=mysqli_fetch_array($laksana_soalan))
{
	# mengumpukkan data soalan kepada tatasusunan $data_get
	$data_get=array(
		'no_set'    => $data['no_set'],
		'no_soalan' => $data['no_soalan'],
		'topik'     => $_GET['topik'],
		'soalan'    => $data['soalan'],
		'jawapan_a' => $data['jawapan_a'],
		'jawapan_b' => $data['jawapan_b']
	);
	# memaparkan data ynag ditemui baris demi baris
	echo "<tr>
	    <td>    ".$data['soalan'].      "</td>
	    <td>    ".$data['jawapan_a'].   "</td>
	    <td>    ".$data['jawapan_b'].   "</td>
	    <td class='w3-center'>

 <a href='soalan_kemaskini.php?".http_build_query($data_get)."' title='Kemaskini'><i class='w3-xxlarge fa fa-pencil-square-o' aria-hidden='true'></i></a>
 <a href='padam.php?jadual=soalan&medan=no_soalan&kp=".$data['no_soalan']."' title='Padam'><i class='w3-xxlarge fa fa-trash' aria-hidden='true'></i></a>
</td>
    </tr>";
}
?>

</table>
</div>
<?PHP include('footer_guru.php'); ?>