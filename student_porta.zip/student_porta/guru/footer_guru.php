</div>

<!--footer -->
<?PHP include('../iklan_bawah.php')?>
<div class="w3-container w3-purple">
  <p>Hakcipta &copy 2020-2021 : smh</p>
  <p>Penafian : Pihak admin tidak bertanggungjawab atas kerugian dan kehilangan akibat penggunaan data yang terkandung dalam sistem ini</p>
</div>
<?PHP mysqli_close($condb); ?>

</body>
</html>