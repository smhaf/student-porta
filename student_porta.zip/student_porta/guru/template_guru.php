<?php
#memulakan fungsi sesion
session_start();

#MEMANGGGIL FAIL guard_guru.PHP
include ('guard_guru.php');

#memangil fail connecotion dari folder utama
include ('../connection.php');

#menguji pemboleh ubahsession tahap mempunayi nilai atau tidak
if(empty($_SESSION['tahap']))
{
    #proses untuk mendapatkan tahap penggna yang sedang login samada admin atau guru
    $arahan_semak_tahap="select* from guru where 
    nokp_guru   =   '".$_SESSION['nokp_guru']."'
    limit 1";
    $laksana_semak_tahap=mysqli_query($condb,$arahan_semak_tahap);
    $data=mysqli_fetch_array($laksana_semak_tahap);
    $_SESSION['tahap']=$data['tahap'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Pembelajaran Online</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lobster&effect=shadow-multiple">
    <style>
    .w3-tajuk {
    font-family: "Lobster", Sans-serif;
    }
    </style>
</head>
<body background='../images/background1.png'>
    

<!--header -->
<div class="w3-container w3-green">
    <h1 class="w3-tajuk w3-xxlarge font-effect-shadow-multiple w3-text-black" ><B>Bahagian Guru / Aministrator</B></h1>
</div>

<!--menu -->
<div class="w3-bar w3-purple">
  <a href='index.php' class="w3-bar-item w3-button">Laman Utama</a>
  <a href='../logout.php' class="w3-bar-item w3-button w3-right">Logout</a>

  <?PHP if($_SESSION['tahap']=='ADMIN'){ ?>

  <div class="w3-dropdown-hover">
    <button class="w3-button">Admin</button>
    <div class="w3-dropdown-content w3-bar-block w3-card-4">
      <a href='guru_senarai.php' class="w3-bar-item w3-button">Maklumat Guru</a>
      <a href='murid_senarai.php' class="w3-bar-item w3-button">Pengurusan Murid</a>
      <a href='senarai_kelas.php' class="w3-bar-item w3-button">Pengurusan Kelas</a>
    </div>
  </div>
  
  <?PHP } ?>

  <div class="w3-dropdown-hover">
    <button class="w3-button">Guru</button>
    <div class="w3-dropdown-content w3-bar-block w3-card-4">
      <a href='soalan_set.php' class="w3-bar-item w3-button">Pengurusan Soalan</a>
      <a href='analisis.php' class="w3-bar-item w3-button">Analisis Prestasi</a>

    </div>
  </div>
</div>

<!--isikandungan -->
<div class="w3-container">
  <p>The w3-container class is an important w3.CSS class.</p>
</div>

<!--footer -->
<?PHP include('../iklan_bawah.php')?>
<div class="w3-container w3-purple">
  <p>Hakcipta &copy 2020-2021 : smh</p>
  <p>Penafian : Pihak admin tidak bertanggungjawab atas kerugian dan kehilangan akibat penggunaan data yang terkandung dalam sistem ini</p>
</div>
<?PHP mysqli_close($condb); ?>

</body>
</html>