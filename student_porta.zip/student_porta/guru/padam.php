<?PHP
#memulakan fungsi sesion start
session_start();

# menyemak kewujudan data get
if(!empty($_GET))
{
	include('../connection.php');

	#mengambar data yang dihantar
	$jadual    =   $_GET['jadual'];
	$medan     =   $_GET['medan'];
	$kp        =   $_GET['kp'];

	#arahan untuk memadam rekod didalam jadual 
	$arahan_padam="delete from $jadual where $medan='$kp'";

	#laksana arahan padam rekod
	if(mysqli_query($condb,$arahan_padam))
	{
		# berjaya
		echo "<script>alert('data BERJAYA dipadam');
		window.history.back();</script>";
	}
	else
	{
		# gagal
		echo "<script>alert('data GAGAL dipadam');
		window.history.back();</script>";
	}
	
} 
else
{
	die("<script>alert('Akses fail tanpa kebenaran');
	window.history.back();</script>");
}
?>