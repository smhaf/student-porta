</div>
<?php include('iklan_bawah.php')?>
<!-- footer-->
<div class='w3-container w3-purple'>
	<!-- Gunakan ayat lebih sesuai pada bahagian ini -->
<p>Hakcipta &copy 2020-2021 : smh </p>

<p>Penafian : Pihak admin tidak bertanggungjawab atas kerugian dan kehilangan akibat penggunaan data yang terkandung dalam sistem ini</p>
</div>

</body>
</html>